// SuperLocalMemory V2 - Event Listener Wiring
// Loads LAST — after all module scripts. Connects UI events to module functions.

document.getElementById('memories-tab').addEventListener('shown.bs.tab', loadMemories);
document.getElementById('clusters-tab').addEventListener('shown.bs.tab', loadClusters);
document.getElementById('patterns-tab').addEventListener('shown.bs.tab', loadPatterns);
document.getElementById('timeline-tab').addEventListener('shown.bs.tab', loadTimeline);
document.getElementById('settings-tab').addEventListener('shown.bs.tab', loadSettings);
document.getElementById('search-query').addEventListener('keypress', function(e) { if (e.key === 'Enter') searchMemories(); });

document.getElementById('profile-select').addEventListener('change', function() {
    switchProfile(this.value);
});

document.getElementById('add-profile-btn').addEventListener('click', function() {
    createProfile();
});

var newProfileInput = document.getElementById('new-profile-name');
if (newProfileInput) {
    newProfileInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') createProfile();
    });
}

// v2.5 tabs (graceful — elements may not exist on older installs)
var eventsTab = document.getElementById('events-tab');
if (eventsTab) eventsTab.addEventListener('shown.bs.tab', loadEventStats);

var agentsTab = document.getElementById('agents-tab');
if (agentsTab) agentsTab.addEventListener('shown.bs.tab', loadAgents);

// v2.7 learning tab (graceful)
var learningTab = document.getElementById('learning-tab');
if (learningTab) learningTab.addEventListener('shown.bs.tab', loadLearning);

// v2.8 tabs (graceful — elements may not exist on older installs)
var lifecycleTab = document.getElementById('lifecycle-tab');
if (lifecycleTab) lifecycleTab.addEventListener('shown.bs.tab', loadLifecycle);

var behavioralTab = document.getElementById('behavioral-tab');
if (behavioralTab) behavioralTab.addEventListener('shown.bs.tab', loadBehavioral);

var complianceTab = document.getElementById('compliance-tab');
if (complianceTab) complianceTab.addEventListener('shown.bs.tab', loadCompliance);
